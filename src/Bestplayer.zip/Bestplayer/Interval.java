package Bestplayer;

/**
 * Created by Ivan on 1/17/2017.
 */
public class Interval {
    float rads;
}
